const menuToggle = document.getElementById('menuToggle');
const navMenu = document.getElementById('navMenu');
menuToggle.addEventListener('click', () => {
  const open = navMenu.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
navMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  navMenu.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

document.getElementById('year').textContent = new Date().getFullYear();

document.querySelectorAll('.course-enquire').forEach(button => {
  button.addEventListener('click', () => {
    const course = button.dataset.course;
    document.getElementById('course').value = course;
    document.getElementById('enquiry').scrollIntoView({ behavior: 'smooth' });
    document.getElementById('studentName').focus({ preventScroll: true });
  });
});

const form = document.getElementById('enquiryForm');
form.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!form.reportValidity()) return;
  const name = document.getElementById('studentName').value.trim();
  const mobile = document.getElementById('mobile').value.trim();
  const course = document.getElementById('course').value;
  const mode = document.getElementById('mode').value;
  const message = document.getElementById('message').value.trim();
  const text = [
    'Namaste Real-Tech Computer Center!',
    'Admission Course Enquiry:',
    `Student Name: ${name}`,
    `Mobile Number: ${mobile}`,
    `Course: ${course}`,
    `Learning Mode: ${mode}`,
    message ? `Message: ${message}` : ''
  ].filter(Boolean).join('\n');
  document.getElementById('formStatus').textContent = 'WhatsApp खुल रहा है। कृपया message review करके Send दबाएँ।';
  const whatsappUrl = `https://wa.me/919079148033?text=${encodeURIComponent(text)}`;
  window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
});
