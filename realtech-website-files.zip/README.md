# Real-Tech Computer Center Website

Responsive static website for GitHub Pages.

## Files
- `index.html` — page structure and course catalog
- `style.css` — responsive design
- `script.js` — mobile menu, course selection, WhatsApp enquiry form

## Publish using GitHub Pages
1. Sign in to GitHub as `realtechdigitalwork`.
2. Create a repository named `realtech-computer-center` (Public is the simplest setup for GitHub Pages).
3. Upload these three files from this ZIP to the repository root.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. After deployment, the website URL will typically be:
   `https://realtechdigitalwork.github.io/realtech-computer-center/`

## Enquiry form behavior
The form opens a pre-filled WhatsApp message to `+91 9079148033`; visitor must tap Send in WhatsApp. It does not store enquiry submissions in a database.

## Customize
Edit the course names, text, contact details, or theme in `index.html` / `style.css`.
